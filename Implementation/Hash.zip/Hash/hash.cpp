#include<iostream>
#include<cstdlib>
#include<string>
#include "hash.h"
using namespace std;


//constructor
Hash::Hash(){
  for (int i=0; i<SIZE;++i){
    HashTable[i] = new Value;
    HashTable[i] -> i = 0;
    HashTable[i] -> d = 0.0;
    HashTable[i] -> s = "";
    HashTable[i] -> next = NULL;
  }
}

int Hash::hash_Function(int key){
  //mod
  int idx=key%SIZE;
  return idx;
}

void Hash::setValue(int key, int i, double d, string s){
  int idx = hash_Function(key);

  if(HashTable[idx] -> s == ""){
    HashTable[idx] -> i = i;
    HashTable[idx] -> d = d;
    HashTable[idx] -> s = s;
  }
  else{
    Value* ptr = HashTable[idx];
    Value* nxt = new Value;
    n -> i = i;
    n -> d = d;
    n -> s = s;
    n -> next = NULL;

    while(ptr -> next != NULL){
      ptr = ptr -> next;
    }

    ptr -> next = nxt;
  }

  bool find(int key){
    int idx = hash_Function(key);
    if(HashTable[idx] -> s ="")
      return false;
    else
      return true;
  }
}
